#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SBATCH_SCRIPT="${SCRIPT_DIR}/run_enamine_superchunk_array.sbatch"
PYTHON_SCRIPT="${SCRIPT_DIR}/filter_enamine_superchunk_slurm.py"

SIMILARITY_ROOT=""
OUTPUT_ROOT=""
ARRAY_RANGE="0-530%1"
WORKERS=60
CPUS=60
MEMORY="120G"
WALLTIME="24:00:00"
SCRATCH_ROOT="/scratch/ari_ginsparg_umassmed"
OVERWRITE=0
KEEP_MANIFESTS=0

usage() {
    cat <<EOF
Usage: $0 --similarity-root PATH --output-root PATH [options]

Options:
  --array SPEC
  --workers N
  --cpus N
  --mem SIZE
  --time H:MM:SS
  --scratch-root PATH
  --overwrite
  --keep-manifests
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --similarity-root) SIMILARITY_ROOT="$2"; shift 2 ;;
        --output-root) OUTPUT_ROOT="$2"; shift 2 ;;
        --array) ARRAY_RANGE="$2"; shift 2 ;;
        --workers) WORKERS="$2"; shift 2 ;;
        --cpus) CPUS="$2"; shift 2 ;;
        --mem) MEMORY="$2"; shift 2 ;;
        --time) WALLTIME="$2"; shift 2 ;;
        --scratch-root) SCRATCH_ROOT="$2"; shift 2 ;;
        --overwrite) OVERWRITE=1; shift ;;
        --keep-manifests) KEEP_MANIFESTS=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 2 ;;
    esac
done

if [[ -z "${SIMILARITY_ROOT}" || -z "${OUTPUT_ROOT}" ]]; then
    echo "ERROR: --similarity-root and --output-root are required." >&2
    exit 2
fi

if [[ ! -f "${SBATCH_SCRIPT}" ]]; then
    echo "ERROR: sbatch script not found: ${SBATCH_SCRIPT}" >&2
    exit 2
fi

if [[ ! -f "${PYTHON_SCRIPT}" ]]; then
    echo "ERROR: Python script not found: ${PYTHON_SCRIPT}" >&2
    exit 2
fi

# Canonical absolute paths before submission.
SBATCH_SCRIPT="$(readlink -f "${SBATCH_SCRIPT}")"
PYTHON_SCRIPT="$(readlink -f "${PYTHON_SCRIPT}")"
SIMILARITY_ROOT="$(readlink -f "${SIMILARITY_ROOT}")"
mkdir -p "${OUTPUT_ROOT}" "${SCRATCH_ROOT}" /scratch/ari_ginsparg_umassmed/enamine_filter_logs
OUTPUT_ROOT="$(readlink -f "${OUTPUT_ROOT}")"
SCRATCH_ROOT="$(readlink -f "${SCRATCH_ROOT}")"

echo "Submitting batch script: ${SBATCH_SCRIPT}"
echo "Passing Python script:   ${PYTHON_SCRIPT}"

EXPORTS="ALL"
EXPORTS+=",SIMILARITY_ROOT=${SIMILARITY_ROOT}"
EXPORTS+=",OUTPUT_ROOT=${OUTPUT_ROOT}"
EXPORTS+=",SCRATCH_ROOT=${SCRATCH_ROOT}"
EXPORTS+=",WORKERS=${WORKERS}"
EXPORTS+=",OVERWRITE=${OVERWRITE}"
EXPORTS+=",KEEP_MANIFESTS=${KEEP_MANIFESTS}"

# PYTHON_SCRIPT is passed after the batch filename as $1, not inferred from
# BASH_SOURCE and not dependent on Slurm's spool-directory behavior.
sbatch \
    --partition=cpu \
    --array="${ARRAY_RANGE}" \
    --cpus-per-task="${CPUS}" \
    --mem="${MEMORY}" \
    --time="${WALLTIME}" \
    --export="${EXPORTS}" \
    "${SBATCH_SCRIPT}" \
    "${PYTHON_SCRIPT}"
