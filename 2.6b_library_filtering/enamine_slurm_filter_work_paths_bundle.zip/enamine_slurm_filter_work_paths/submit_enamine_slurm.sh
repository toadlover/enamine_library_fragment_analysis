#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SBATCH_SCRIPT="$SCRIPT_DIR/run_enamine_superchunk_array.sbatch"
PYTHON_SCRIPT="$SCRIPT_DIR/filter_enamine_superchunk_slurm.py"

LIBRARY_ROOT="/work/umassmed/thymelab_umassmed/2.6b_conformer_library"
SIMILARITY_ROOT=""
OUTPUT_ROOT=""
SCRATCH_ROOT="/scratch/ari_ginsparg_umassmed"
ARRAY_RANGE="0-530%1"
WORKERS=60
CPUS=60
MEMORY="120G"
WALLTIME="24:00:00"
OVERWRITE=0
KEEP_MANIFESTS=0

usage() {
  cat <<USAGE
Usage: $0 --similarity-root PATH --output-root PATH [options]

Options:
  --library-root PATH   Default: $LIBRARY_ROOT
  --scratch-root PATH   Default: $SCRATCH_ROOT
  --array SPEC          Default: $ARRAY_RANGE
  --workers N           Default: $WORKERS
  --cpus N              Default: $CPUS
  --mem SIZE            Default: $MEMORY
  --time H:MM:SS        Default: $WALLTIME
  --overwrite
  --keep-manifests
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --library-root) LIBRARY_ROOT="$2"; shift 2 ;;
    --similarity-root) SIMILARITY_ROOT="$2"; shift 2 ;;
    --output-root) OUTPUT_ROOT="$2"; shift 2 ;;
    --scratch-root) SCRATCH_ROOT="$2"; shift 2 ;;
    --array) ARRAY_RANGE="$2"; shift 2 ;;
    --workers) WORKERS="$2"; shift 2 ;;
    --cpus) CPUS="$2"; shift 2 ;;
    --mem) MEMORY="$2"; shift 2 ;;
    --time) WALLTIME="$2"; shift 2 ;;
    --overwrite) OVERWRITE=1; shift ;;
    --keep-manifests) KEEP_MANIFESTS=1; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

[[ -n "$SIMILARITY_ROOT" && -n "$OUTPUT_ROOT" ]] || { echo "ERROR: --similarity-root and --output-root are required" >&2; exit 2; }
[[ -f "$SBATCH_SCRIPT" ]] || { echo "ERROR: missing $SBATCH_SCRIPT" >&2; exit 2; }
[[ -f "$PYTHON_SCRIPT" ]] || { echo "ERROR: missing $PYTHON_SCRIPT" >&2; exit 2; }
[[ -d "$LIBRARY_ROOT" ]] || { echo "ERROR: library root not found: $LIBRARY_ROOT" >&2; exit 2; }
[[ -d "$SIMILARITY_ROOT" ]] || { echo "ERROR: similarity root not found: $SIMILARITY_ROOT" >&2; exit 2; }

SBATCH_SCRIPT="$(readlink -f "$SBATCH_SCRIPT")"
PYTHON_SCRIPT="$(readlink -f "$PYTHON_SCRIPT")"
LIBRARY_ROOT="$(readlink -f "$LIBRARY_ROOT")"
SIMILARITY_ROOT="$(readlink -f "$SIMILARITY_ROOT")"
mkdir -p "$OUTPUT_ROOT" "$SCRATCH_ROOT" /scratch/ari_ginsparg_umassmed/enamine_filter_logs
OUTPUT_ROOT="$(readlink -f "$OUTPUT_ROOT")"
SCRATCH_ROOT="$(readlink -f "$SCRATCH_ROOT")"

cat <<INFO
Submitting:
  Python script:   $PYTHON_SCRIPT
  Library root:    $LIBRARY_ROOT
  Similarity root: $SIMILARITY_ROOT
  Output root:     $OUTPUT_ROOT
  Scratch root:    $SCRATCH_ROOT
  Array:           $ARRAY_RANGE
  Workers/CPUs:    $WORKERS/$CPUS
INFO

EXPORTS="ALL,LIBRARY_ROOT=$LIBRARY_ROOT,SIMILARITY_ROOT=$SIMILARITY_ROOT,OUTPUT_ROOT=$OUTPUT_ROOT,SCRATCH_ROOT=$SCRATCH_ROOT,WORKERS=$WORKERS,OVERWRITE=$OVERWRITE,KEEP_MANIFESTS=$KEEP_MANIFESTS"

sbatch \
  --partition=cpu \
  --array="$ARRAY_RANGE" \
  --cpus-per-task="$CPUS" \
  --mem="$MEMORY" \
  --time="$WALLTIME" \
  --export="$EXPORTS" \
  "$SBATCH_SCRIPT" \
  "$PYTHON_SCRIPT"
