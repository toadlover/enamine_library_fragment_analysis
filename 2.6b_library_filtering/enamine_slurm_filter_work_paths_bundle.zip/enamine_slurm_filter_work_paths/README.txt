Example:

bash submit_enamine_slurm.sh \
  --similarity-root /work/umassmed/thymelab_umassmed/2.6b_conformer_library/removal_files \
  --output-root /work/umassmed/thymelab_umassmed/filtered_2.6b_library \
  --array '0-10%1' \
  --workers 27 \
  --cpus 27 \
  --mem 72G
