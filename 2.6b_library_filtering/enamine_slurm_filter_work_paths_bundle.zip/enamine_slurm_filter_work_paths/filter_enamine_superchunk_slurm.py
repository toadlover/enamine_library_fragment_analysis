#!/usr/bin/env python3
import argparse,csv,io,json,os,re,shutil,subprocess,sys,tarfile,tempfile,time
from concurrent.futures import ProcessPoolExecutor,as_completed
from pathlib import Path

LIB=Path('/work/umassmed/thymelab_umassmed/2.6b_conformer_library')
SCRATCH=Path('/scratch/ari_ginsparg_umassmed')
SUBS=range(10)

def log(s): print(f"[{time.strftime('%F %T')}] {s}",flush=True)
def run(cmd): return subprocess.run(cmd,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
def rm_tree(p):
    try: shutil.rmtree(p)
    except Exception: pass

def sim_report(root,sc,ch):
    d=root/str(sc)/f'{ch:05d}'; b=f'chunk_{ch:05d}_similarity_report.csv'
    for p in (d/(b+'.tar.gz'),d/b):
        if p.is_file(): return p
    raise FileNotFoundError(f'No similarity report for chunk {ch:05d}')

def parse_similarity(path):
    out={i:set() for i in SUBS}
    def consume(h):
        r=csv.DictReader(h); need={'name','status','subchunk'}
        miss=need-set(r.fieldnames or [])
        if miss: raise ValueError(f'{path} missing columns: {sorted(miss)}')
        for row in r:
            if (row['status'] or '').strip().lower()!='removed': continue
            name=(row['name'] or '').strip()
            if not name: continue
            s=int(row['subchunk']); out[s].add(name)
    if path.name.endswith('.tar.gz'):
        with tarfile.open(path,'r:gz') as t:
            ms=[m for m in t.getmembers() if m.isfile() and m.name.endswith('.csv')]
            if len(ms)!=1: raise ValueError(f'{path} must contain one CSV')
            f=t.extractfile(ms[0])
            with f,io.TextIOWrapper(f,encoding='utf-8-sig',newline='') as h: consume(h)
    else:
        with path.open(encoding='utf-8-sig',newline='') as h: consume(h)
    return out

def parse_blacklist(path):
    out={i:set() for i in SUBS}
    with path.open(encoding='utf-8-sig',newline='') as h:
        r=csv.DictReader(h); need={'ligand','subchunk_splitfile'}
        miss=need-set(r.fieldnames or [])
        if miss: raise ValueError(f'{path} missing columns: {sorted(miss)}')
        for row in r:
            name=(row['ligand'] or '').strip(); src=(row['subchunk_splitfile'] or '').strip()
            if not name: continue
            m=re.search(r'named_(\d+)\.sdf(?:\.tar\.gz)?$',src)
            if not m: raise ValueError(f'Cannot derive subchunk from {src}')
            out[int(m.group(1))].add(name)
    return out

def esc(s): return s.replace('[','[[]').replace('*','[*]').replace('?','[?]')
def write_manifest(path,names):
    with path.open('w') as h:
        h.write('db.db\n*lig_name_lis*\n')
        for n in sorted(names): h.write(f'*{esc(n)}*\n')

def root_in_archive(a):
    lines=run(['tar','-tzf',str(a)]).stdout.splitlines(); roots=set()
    rx=re.compile(r'^((?:\./)?condensed_params_and_db_[^/]+/single_conf_params)(?:/|$)')
    for x in lines:
        m=rx.match(x)
        if m: roots.add(m.group(1))
    if len(roots)!=1: raise RuntimeError(f'{a}: expected one single_conf_params root, got {roots}')
    return next(iter(roots))

def validate(a):
    lines=run(['tar','-tzf',str(a)]).stdout.splitlines()
    bad=[x for x in lines if ('/single_conf_params/' not in x and not x.rstrip('/').endswith('/single_conf_params')) or x.endswith('/db.db') or 'lig_name_lis' in x]
    if bad: raise RuntimeError(f'{a}: invalid members: {bad[:5]}')
    return len(lines)

def build_archive(src,dst,manifest,work,sub):
    ext=work/f'extract_{sub}'; ext.mkdir(parents=True)
    part=dst.with_name(dst.name+'.partial'); root=root_in_archive(src)
    try:
        run(['tar','-xzf',str(src),'-C',str(ext),'--wildcards','--no-anchored','--exclude-from',str(manifest),root])
        if not (ext/root).is_dir(): raise RuntimeError(f'Extraction root missing: {ext/root}')
        run(['tar','-czf',str(part),'-C',str(ext),root])
        count=validate(part); os.replace(part,dst)
        return {'subchunk':sub,'members':count,'bytes':dst.stat().st_size}
    finally:
        if part.exists(): part.unlink()
        rm_tree(ext)

def install(srcdir,dstdir,overwrite):
    dstdir.mkdir(parents=True,exist_ok=True)
    for src in srcdir.iterdir():
        dst=dstdir/src.name
        if dst.exists():
            if not overwrite: raise FileExistsError(dst)
            dst.unlink()
        part=dst.with_name(dst.name+'.partial')
        shutil.copy2(src,part); os.replace(part,dst)

def process_chunk(cfg,ch):
    lib=Path(cfg['lib']); sim=Path(cfg['sim']); out=Path(cfg['out']); scratch=Path(cfg['scratch'])
    sc=ch//100; name=f'{ch:05d}'; srcdir=lib/str(sc)/name; final=out/str(sc)/name; marker=final/f'chunk_{name}.complete'
    if marker.is_file() and not cfg['overwrite']: return (ch,'skipped',0.0)
    start=time.time(); tmp=Path(tempfile.mkdtemp(prefix=f'chunk_{name}_',dir=str(scratch/'enamine_filter'/str(sc))))
    outputs=tmp/'outputs'; work=tmp/'work'; manifests=tmp/'manifests'
    outputs.mkdir(); work.mkdir(); manifests.mkdir()
    try:
        s=parse_similarity(sim_report(sim,sc,ch)); b=parse_blacklist(srcdir/'blacklist_file.csv')
        results=[]; counts={}
        for sub in SUBS:
            src=srcdir/f'condensed_params_and_db_{sub}.tar.gz'
            if not src.is_file():
                if cfg['allow_missing']: continue
                raise FileNotFoundError(src)
            names=s[sub]|b[sub]; man=manifests/f'exclude_{sub}.txt'; write_manifest(man,names)
            counts[str(sub)]={'similarity_removed':len(s[sub]),'blacklist':len(b[sub]),'unique_total':len(names)}
            results.append(build_archive(src,outputs/src.name,man,work,sub))
            if cfg['keep_manifests']: shutil.copy2(man,outputs/f'chunk_{name}_exclude_{sub}.txt')
        if not cfg['allow_missing'] and len(results)!=10: raise RuntimeError(f'Built {len(results)} archives')
        with (outputs/f'chunk_{name}_summary.json').open('w') as h:
            json.dump({'chunk':ch,'superchunk':sc,'archives':results,'exclusions':counts},h,indent=2)
        install(outputs,final,cfg['overwrite'])
        p=final/f'chunk_{name}.complete.partial'; p.write_text(f'chunk={name}\nsuperchunk={sc}\ncompleted={time.strftime("%F %T")}\n')
        os.replace(p,marker); rm_tree(tmp)
        return (ch,'completed',time.time()-start)
    except Exception:
        raise RuntimeError(f'chunk {name} failed; scratch retained at {tmp}')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('superchunk',type=int); ap.add_argument('similarity_root',type=Path); ap.add_argument('output_root',type=Path)
    ap.add_argument('--library-root',type=Path,default=LIB); ap.add_argument('--scratch-root',type=Path,default=SCRATCH); ap.add_argument('--workers',type=int,default=60)
    ap.add_argument('--overwrite',action='store_true'); ap.add_argument('--allow-missing-archives',action='store_true'); ap.add_argument('--keep-manifests',action='store_true'); a=ap.parse_args()
    if not 0<=a.superchunk<=530: sys.exit('superchunk must be 0-530')
    scdir=a.library_root.resolve()/str(a.superchunk)
    chunks=sorted(int(p.name) for p in scdir.iterdir() if p.is_dir() and re.fullmatch(r'\d{5}',p.name) and int(p.name)//100==a.superchunk)
    cpus=int(os.environ.get('SLURM_CPUS_PER_TASK',a.workers)); workers=min(a.workers,cpus,len(chunks))
    scratch=(a.scratch_root.resolve()/'enamine_filter'/str(a.superchunk)); scratch.mkdir(parents=True,exist_ok=True); a.output_root.mkdir(parents=True,exist_ok=True)
    cfg={'lib':str(a.library_root.resolve()),'sim':str(a.similarity_root.resolve()),'out':str(a.output_root.resolve()),'scratch':str(a.scratch_root.resolve()),'overwrite':a.overwrite,'allow_missing':a.allow_missing_archives,'keep_manifests':a.keep_manifests}
    log(f'Superchunk {a.superchunk}: {len(chunks)} chunks with {workers} workers')
    failures=[]; completed=skipped=0
    with ProcessPoolExecutor(max_workers=workers) as ex:
        fut={ex.submit(process_chunk,cfg,ch):ch for ch in chunks}
        for f in as_completed(fut):
            ch=fut[f]
            try:
                _,status,elapsed=f.result(); completed+=status=='completed'; skipped+=status=='skipped'; log(f'chunk {ch:05d}: {status} ({elapsed:.1f}s)')
            except Exception as e: failures.append((ch,str(e))); log(f'ERROR chunk {ch:05d}: {e}')
    outsc=a.output_root.resolve()/str(a.superchunk); outsc.mkdir(parents=True,exist_ok=True)
    summary=outsc/f'superchunk_{a.superchunk}_run_summary.json'; summary.write_text(json.dumps({'superchunk':a.superchunk,'workers':workers,'completed':completed,'skipped':skipped,'failures':[{'chunk':c,'error':e} for c,e in failures]},indent=2))
    if failures: return 1
    (outsc/f'superchunk_{a.superchunk}.complete').write_text(f'superchunk={a.superchunk}\ncompleted={time.strftime("%F %T")}\n')
    return 0
if __name__=='__main__': sys.exit(main())
