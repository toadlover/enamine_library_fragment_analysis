#!/usr/bin/env python3
"""
filter_and_transfer_enamine_chunk.py

For one Enamine REAL 2.6B chunk:

1. Read blacklist_file.csv and the prior similarity report.
2. Rebuild condensed_params_and_db_0..9.tar.gz so they contain only
   condensed_params_and_db_*/single_conf_params, excluding:
       db.db
       *lig_name_lis*
       any blacklisted ligand name
       any similarity-report ligand with status == removed
3. Transfer those ten filtered parameter archives to AICR.
4. Transfer the ten original split_new_named_*.sdf.tar.gz archives untouched.
5. Verify all transferred file sizes remotely.
6. chmod the remote chunk directory.
7. Delete all locally created staging data only after all prior steps succeed.

The original Enamine library and the similarity reports are never modified.
"""

import argparse
import csv
import errno
import io
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import time
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple


LIBRARY_ROOT_DEFAULT = Path("/pi/summer.thyme-umw/enamine-REAL-2.6billion")
REMOTE_HOST_DEFAULT = "ari_ginsparg_umassmed@login.aicr.ai"
REMOTE_BASE_DEFAULT = "/work/umassmed/thymelab_umassmed/2.6b_conformer_library"
SSH_KEY_DEFAULT = Path.home() / ".ssh" / "id_ed25519_aicr"

PARAM_ARCHIVE_TEMPLATE = "condensed_params_and_db_{}.tar.gz"
SDF_ARCHIVE_TEMPLATE = "split_new_named_{}.sdf.tar.gz"
SIMILARITY_REPORT_TEMPLATE = "chunk_{:05d}_similarity_report.csv"
EXPECTED_SUBCHUNKS = tuple(range(10))

NAME_COLUMN_CANDIDATES = (
    "name",
    "ligand_name",
    "lig_name",
    "ligand",
    "title",
    "id",
    "identifier",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Filter and transfer one Enamine chunk to AICR."
    )
    parser.add_argument("chunk", type=int, help="Global chunk number, 0-53083.")
    parser.add_argument(
        "similarity_root",
        type=Path,
        help=(
            "Root containing <superchunk>/<chunk>/"
            "chunk_<chunk>_similarity_report.csv.tar.gz."
        ),
    )
    parser.add_argument(
        "staging_root",
        type=Path,
        help=(
            "Local scratch root for temporary filtered parameter archives. "
            "The chunk staging directory is deleted after successful transfer."
        ),
    )
    parser.add_argument(
        "--library-root",
        type=Path,
        default=LIBRARY_ROOT_DEFAULT,
    )
    parser.add_argument("--remote-host", default=REMOTE_HOST_DEFAULT)
    parser.add_argument("--remote-base", default=REMOTE_BASE_DEFAULT)
    parser.add_argument("--ssh-key", type=Path, default=SSH_KEY_DEFAULT)
    parser.add_argument("--remote-mode", default="777")
    parser.add_argument("--blacklist-name-column", default=None)
    parser.add_argument("--similarity-name-column", default=None)
    parser.add_argument("--similarity-status-column", default="status")
    parser.add_argument("--removed-status", default="removed")
    parser.add_argument(
        "--allow-missing-archives",
        action="store_true",
        help="Process available archive pairs instead of requiring all ten.",
    )
    parser.add_argument(
        "--keep-staging-on-success",
        action="store_true",
        help="Retain generated parameter archives after successful transfer.",
    )
    parser.add_argument(
        "--rsync-progress",
        action="store_true",
        help="Show rsync progress2 output. Otherwise use concise statistics.",
    )
    return parser.parse_args()


def log(message: str) -> None:
    print(
        "[{}] {}".format(time.strftime("%Y-%m-%d %H:%M:%S"), message),
        flush=True,
    )


def chunk_path(root: Path, chunk: int) -> Tuple[int, Path]:
    superchunk = chunk // 100
    return superchunk, root / str(superchunk) / "{:05d}".format(chunk)


def run_checked(command: Sequence[str]) -> subprocess.CompletedProcess:
    log("Running: {}".format(" ".join(shlex.quote(str(x)) for x in command)))
    return subprocess.run(list(command), check=True)


def detect_column(
    fieldnames: Sequence[str],
    requested: Optional[str],
) -> str:
    normalized = {name.strip().lower(): name for name in fieldnames if name}

    if requested:
        key = requested.strip().lower()
        if key not in normalized:
            raise ValueError(
                "Requested column {!r} not found. Available columns: {}".format(
                    requested, ", ".join(fieldnames)
                )
            )
        return normalized[key]

    for candidate in NAME_COLUMN_CANDIDATES:
        if candidate in normalized:
            return normalized[candidate]

    raise ValueError(
        "Could not auto-detect a ligand-name column. Available columns: {}".format(
            ", ".join(fieldnames)
        )
    )


def read_csv_names(
    handle: io.TextIOBase,
    requested_name_column: Optional[str],
    status_column: Optional[str] = None,
    required_status: Optional[str] = None,
) -> Set[str]:
    reader = csv.DictReader(handle)
    if not reader.fieldnames:
        raise ValueError("CSV has no header row.")

    name_column = detect_column(reader.fieldnames, requested_name_column)

    actual_status_column = None
    if status_column is not None:
        normalized = {
            name.strip().lower(): name for name in reader.fieldnames if name
        }
        key = status_column.strip().lower()
        if key not in normalized:
            raise ValueError(
                "Status column {!r} not found. Available columns: {}".format(
                    status_column, ", ".join(reader.fieldnames)
                )
            )
        actual_status_column = normalized[key]

    names: Set[str] = set()
    for row in reader:
        if actual_status_column is not None and required_status is not None:
            status = (row.get(actual_status_column) or "").strip().lower()
            if status != required_status.strip().lower():
                continue

        name = (row.get(name_column) or "").strip()
        if name:
            if "\n" in name or "\r" in name:
                raise ValueError(
                    "Ligand name contains a newline: {!r}".format(name)
                )
            names.add(name)

    return names


def read_blacklist(
    blacklist_path: Path,
    requested_column: Optional[str],
) -> Set[str]:
    if not blacklist_path.is_file():
        raise FileNotFoundError(
            "Blacklist file does not exist: {}".format(blacklist_path)
        )

    with blacklist_path.open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        return read_csv_names(handle, requested_column)


def locate_similarity_report(
    similarity_chunk_dir: Path,
    chunk: int,
) -> Path:
    basename = SIMILARITY_REPORT_TEMPLATE.format(chunk)
    candidates = [
        similarity_chunk_dir / (basename + ".tar.gz"),
        similarity_chunk_dir / basename,
    ]

    for candidate in candidates:
        if candidate.is_file():
            return candidate

    raise FileNotFoundError(
        "Similarity report not found. Expected one of:\n  {}".format(
            "\n  ".join(str(path) for path in candidates)
        )
    )


def read_similarity_names(
    report_path: Path,
    requested_name_column: Optional[str],
    status_column: str,
    removed_status: str,
) -> Set[str]:
    if report_path.name.endswith(".tar.gz"):
        with tarfile.open(str(report_path), "r:gz") as archive:
            csv_members = [
                member
                for member in archive.getmembers()
                if member.isfile() and member.name.lower().endswith(".csv")
            ]
            if len(csv_members) != 1:
                raise ValueError(
                    "Expected exactly one CSV in {}, found {}.".format(
                        report_path, len(csv_members)
                    )
                )

            extracted = archive.extractfile(csv_members[0])
            if extracted is None:
                raise ValueError(
                    "Could not read {} from {}".format(
                        csv_members[0].name, report_path
                    )
                )

            with extracted:
                with io.TextIOWrapper(
                    extracted, encoding="utf-8-sig", newline=""
                ) as text_handle:
                    return read_csv_names(
                        text_handle,
                        requested_name_column,
                        status_column=status_column,
                        required_status=removed_status,
                    )

    with report_path.open(
        "r", encoding="utf-8-sig", newline=""
    ) as handle:
        return read_csv_names(
            handle,
            requested_name_column,
            status_column=status_column,
            required_status=removed_status,
        )


def glob_escape_literal(value: str) -> str:
    output: List[str] = []
    for char in value:
        if char == "*":
            output.append("[*]")
        elif char == "?":
            output.append("[?]")
        elif char == "[":
            output.append("[[]")
        else:
            output.append(char)
    return "".join(output)


def write_exclude_manifest(
    manifest_path: Path,
    ligand_names: Iterable[str],
) -> None:
    with manifest_path.open(
        "w", encoding="utf-8", newline="\n"
    ) as handle:
        handle.write("db.db\n")
        handle.write("*lig_name_lis*\n")
        for ligand_name in sorted(set(ligand_names)):
            handle.write(
                "*{}*\n".format(glob_escape_literal(ligand_name))
            )


def list_archive_members(archive_path: Path) -> List[str]:
    result = subprocess.run(
        ["tar", "-tzf", str(archive_path)],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    return [line for line in result.stdout.splitlines() if line]


def find_single_conf_root(members: Sequence[str]) -> str:
    roots: Set[str] = set()
    exact_pattern = re.compile(
        r"^(?:\./)?condensed_params_and_db_[^/]+/single_conf_params/?$"
    )

    for member in members:
        normalized = member.rstrip("/")
        if exact_pattern.match(normalized):
            roots.add(normalized)

    if not roots:
        descendant_pattern = re.compile(
            r"^((?:\./)?condensed_params_and_db_[^/]+/"
            r"single_conf_params)/"
        )
        for member in members:
            match = descendant_pattern.match(member)
            if match:
                roots.add(match.group(1))

    if len(roots) != 1:
        raise ValueError(
            "Expected exactly one single_conf_params root, found {}: {}".format(
                len(roots), ", ".join(sorted(roots))
            )
        )

    return next(iter(roots))


def validate_filtered_archive(archive_path: Path) -> None:
    result = subprocess.run(
        ["tar", "-tzf", str(archive_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(
            "Archive validation failed for {}:\n{}".format(
                archive_path, result.stderr
            )
        )

    members = [line for line in result.stdout.splitlines() if line]
    forbidden = [
        member
        for member in members
        if member == "db.db"
        or member.endswith("/db.db")
        or "lig_name_lis" in member
    ]
    outside = [
        member
        for member in members
        if "/single_conf_params/" not in member
        and not member.rstrip("/").endswith("/single_conf_params")
    ]

    if forbidden:
        raise RuntimeError(
            "Forbidden members remain in {}: {}".format(
                archive_path, ", ".join(forbidden[:10])
            )
        )
    if outside:
        raise RuntimeError(
            "Members outside single_conf_params remain in {}: {}".format(
                archive_path, ", ".join(outside[:10])
            )
        )


def remove_tree_best_effort(path: Path) -> bool:
    if not path.exists():
        return True

    def onerror(function, failed_path, exc_info):
        # PanFS can temporarily leave .panfs.* files with EBUSY/ENOTEMPTY.
        return

    try:
        shutil.rmtree(str(path), onerror=onerror)
    except Exception as exc:
        log("WARNING: staging cleanup issue ignored: {}".format(exc))

    if path.exists():
        log(
            "WARNING: staging directory remains for later cleanup: {}".format(
                path
            )
        )
        return False

    return True


def collect_required_archives(
    source_chunk_dir: Path,
    allow_missing: bool,
) -> Tuple[List[Tuple[int, Path, Path]], List[Path]]:
    """
    Return:
      archive triplets: (subchunk, parameter_archive, sdf_archive)
      missing paths
    """
    pairs: List[Tuple[int, Path, Path]] = []
    missing: List[Path] = []

    for subchunk in EXPECTED_SUBCHUNKS:
        parameter_archive = (
            source_chunk_dir / PARAM_ARCHIVE_TEMPLATE.format(subchunk)
        )
        sdf_archive = source_chunk_dir / SDF_ARCHIVE_TEMPLATE.format(subchunk)

        pair_missing = False
        for archive in (parameter_archive, sdf_archive):
            if not archive.is_file():
                missing.append(archive)
                pair_missing = True

        if not pair_missing:
            pairs.append((subchunk, parameter_archive, sdf_archive))

    if missing and not allow_missing:
        raise FileNotFoundError(
            "Missing expected source archive(s):\n  {}".format(
                "\n  ".join(str(path) for path in missing)
            )
        )

    if not pairs:
        raise FileNotFoundError(
            "No complete parameter/SDF archive pairs were found."
        )

    return pairs, missing


def ssh_base_command(ssh_key: Path) -> List[str]:
    return [
        "ssh",
        "-i",
        str(ssh_key),
        "-o",
        "IdentitiesOnly=yes",
        "-o",
        "ConnectTimeout=30",
        "-o",
        "ServerAliveInterval=60",
        "-o",
        "ServerAliveCountMax=5",
    ]


def rsync_ssh_transport(ssh_key: Path) -> str:
    return " ".join(
        shlex.quote(part)
        for part in [
            "ssh",
            "-i",
            str(ssh_key),
            "-o",
            "IdentitiesOnly=yes",
            "-o",
            "ConnectTimeout=30",
            "-o",
            "ServerAliveInterval=60",
            "-o",
            "ServerAliveCountMax=5",
        ]
    )


def create_remote_directory(
    remote_host: str,
    remote_chunk_dir: str,
    ssh_key: Path,
) -> None:
    command = ssh_base_command(ssh_key)
    command.extend(
        [
            remote_host,
            "mkdir -p {}".format(shlex.quote(remote_chunk_dir)),
        ]
    )
    run_checked(command)


def rsync_files(
    source_files: Sequence[Path],
    remote_host: str,
    remote_chunk_dir: str,
    ssh_key: Path,
    show_progress: bool,
) -> None:
    command = [
        "rsync",
        "-a",
        "--partial",
        "--protect-args",
    ]

    if show_progress:
        command.append("--info=progress2")
    else:
        command.extend(["--info=stats2", "--human-readable"])

    command.extend(
        [
            "-e",
            rsync_ssh_transport(ssh_key),
        ]
    )
    command.extend(str(path) for path in source_files)
    command.append(
        "{}:{}/".format(remote_host, remote_chunk_dir.rstrip("/"))
    )
    run_checked(command)


def verify_remote_sizes(
    local_files: Sequence[Path],
    remote_host: str,
    remote_chunk_dir: str,
    ssh_key: Path,
) -> None:
    expected: Dict[str, int] = {
        path.name: path.stat().st_size for path in local_files
    }

    remote_names = " ".join(
        shlex.quote(name) for name in sorted(expected)
    )
    remote_script = (
        "set -e; cd {directory}; "
        "for f in {names}; do "
        "[ -f \"$f\" ] || {{ echo \"MISSING:$f\"; exit 3; }}; "
        "printf '%s\\t%s\\n' \"$f\" \"$(stat -c %s \"$f\")\"; "
        "done"
    ).format(
        directory=shlex.quote(remote_chunk_dir),
        names=remote_names,
    )

    command = ssh_base_command(ssh_key)
    command.extend([remote_host, remote_script])

    result = subprocess.run(
        command,
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    observed: Dict[str, int] = {}
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        name, size_text = line.split("\t", 1)
        observed[name] = int(size_text)

    missing = sorted(set(expected) - set(observed))
    mismatched = sorted(
        name
        for name, expected_size in expected.items()
        if observed.get(name) != expected_size
    )

    if missing or mismatched:
        raise RuntimeError(
            "Remote verification failed. Missing: {}. Size mismatches: {}.".format(
                ", ".join(missing) if missing else "none",
                ", ".join(mismatched) if mismatched else "none",
            )
        )

    log(
        "Remote verification passed for {} files.".format(len(expected))
    )


def finalize_remote_chunk(
    remote_host: str,
    remote_chunk_dir: str,
    remote_mode: str,
    ssh_key: Path,
    chunk: int,
) -> None:
    marker_name = "chunk_{:05d}.transfer.complete".format(chunk)
    remote_script = (
        "set -e; "
        "chmod -R {mode} {directory}; "
        "printf 'chunk={chunk:05d}\\ncompleted=%s\\n' "
        "\"$(date --iso-8601=seconds)\" > {marker}; "
        "chmod {mode} {marker}"
    ).format(
        mode=shlex.quote(remote_mode),
        directory=shlex.quote(remote_chunk_dir),
        chunk=chunk,
        marker=shlex.quote(
            remote_chunk_dir.rstrip("/") + "/" + marker_name
        ),
    )

    command = ssh_base_command(ssh_key)
    command.extend([remote_host, remote_script])
    run_checked(command)


def build_filtered_parameter_archive(
    source_archive: Path,
    output_archive: Path,
    manifest_path: Path,
    work_root: Path,
    subchunk: int,
) -> None:
    members = list_archive_members(source_archive)
    single_conf_root = find_single_conf_root(members)

    extraction_dir = work_root / "extract_{}".format(subchunk)
    extraction_dir.mkdir(parents=True, exist_ok=True)
    partial_archive = output_archive.with_name(
        output_archive.name + ".partial"
    )

    if partial_archive.exists():
        partial_archive.unlink()

    try:
        run_checked(
            [
                "tar",
                "-xzf",
                str(source_archive),
                "-C",
                str(extraction_dir),
                "--wildcards",
                "--no-anchored",
                "--exclude-from",
                str(manifest_path),
                single_conf_root,
            ]
        )

        extracted_root = extraction_dir / single_conf_root
        if not extracted_root.is_dir():
            raise RuntimeError(
                "Expected extracted directory was not created: {}".format(
                    extracted_root
                )
            )

        run_checked(
            [
                "tar",
                "-czf",
                str(partial_archive),
                "-C",
                str(extraction_dir),
                single_conf_root,
            ]
        )

        validate_filtered_archive(partial_archive)
        os.replace(str(partial_archive), str(output_archive))
    finally:
        try:
            partial_archive.unlink()
        except OSError:
            pass
        remove_tree_best_effort(extraction_dir)


def main() -> int:
    args = parse_args()

    if args.chunk < 0 or args.chunk > 53083:
        print("ERROR: chunk must be between 0 and 53083.", file=sys.stderr)
        return 2

    if not args.ssh_key.is_file():
        print(
            "ERROR: SSH key does not exist: {}".format(args.ssh_key),
            file=sys.stderr,
        )
        return 2

    superchunk, source_chunk_dir = chunk_path(
        args.library_root.resolve(), args.chunk
    )
    _, similarity_chunk_dir = chunk_path(
        args.similarity_root.resolve(), args.chunk
    )

    if not source_chunk_dir.is_dir():
        print(
            "ERROR: source chunk directory does not exist: {}".format(
                source_chunk_dir
            ),
            file=sys.stderr,
        )
        return 2

    try:
        archive_pairs, missing = collect_required_archives(
            source_chunk_dir, args.allow_missing_archives
        )
        similarity_report = locate_similarity_report(
            similarity_chunk_dir, args.chunk
        )
        blacklist_names = read_blacklist(
            source_chunk_dir / "blacklist_file.csv",
            args.blacklist_name_column,
        )
        similarity_names = read_similarity_names(
            similarity_report,
            args.similarity_name_column,
            args.similarity_status_column,
            args.removed_status,
        )
    except Exception as exc:
        print("ERROR: {}".format(exc), file=sys.stderr)
        return 1

    excluded_names = blacklist_names | similarity_names
    remote_chunk_dir = (
        args.remote_base.rstrip("/")
        + "/"
        + str(superchunk)
        + "/"
        + "{:05d}".format(args.chunk)
    )

    args.staging_root.mkdir(parents=True, exist_ok=True)
    staging_dir = Path(
        tempfile.mkdtemp(
            prefix="chunk_{:05d}_".format(args.chunk),
            dir=str(args.staging_root.resolve()),
        )
    )
    filtered_dir = staging_dir / "filtered_parameter_archives"
    work_dir = staging_dir / "work"
    filtered_dir.mkdir(parents=True, exist_ok=True)
    work_dir.mkdir(parents=True, exist_ok=True)

    manifest_path = staging_dir / "tar_excludes.txt"
    write_exclude_manifest(manifest_path, excluded_names)

    log(
        "Chunk {:05d}: {} blacklist names + {} similarity removals "
        "= {} unique exclusions.".format(
            args.chunk,
            len(blacklist_names),
            len(similarity_names),
            len(excluded_names),
        )
    )
    log("Remote destination: {}:{}".format(args.remote_host, remote_chunk_dir))
    log("Local staging directory: {}".format(staging_dir))

    try:
        filtered_archives: List[Path] = []
        sdf_archives: List[Path] = []

        for position, (
            subchunk,
            parameter_archive,
            sdf_archive,
        ) in enumerate(archive_pairs, start=1):
            output_archive = filtered_dir / parameter_archive.name
            log(
                "Building filtered parameter archive {}/{}: {}".format(
                    position, len(archive_pairs), parameter_archive.name
                )
            )
            build_filtered_parameter_archive(
                parameter_archive,
                output_archive,
                manifest_path,
                work_dir,
                subchunk,
            )
            filtered_archives.append(output_archive)
            sdf_archives.append(sdf_archive)

        all_transfer_files = filtered_archives + sdf_archives

        create_remote_directory(
            args.remote_host,
            remote_chunk_dir,
            args.ssh_key,
        )

        log(
            "Transferring {} filtered parameter archives.".format(
                len(filtered_archives)
            )
        )
        rsync_files(
            filtered_archives,
            args.remote_host,
            remote_chunk_dir,
            args.ssh_key,
            args.rsync_progress,
        )

        log(
            "Transferring {} original SDF archives unchanged.".format(
                len(sdf_archives)
            )
        )
        rsync_files(
            sdf_archives,
            args.remote_host,
            remote_chunk_dir,
            args.ssh_key,
            args.rsync_progress,
        )

        verify_remote_sizes(
            all_transfer_files,
            args.remote_host,
            remote_chunk_dir,
            args.ssh_key,
        )

        finalize_remote_chunk(
            args.remote_host,
            remote_chunk_dir,
            args.remote_mode,
            args.ssh_key,
            args.chunk,
        )

    except subprocess.CalledProcessError as exc:
        print(
            "ERROR: command failed with exit status {}. "
            "Staging data was retained at {} for inspection or retry.".format(
                exc.returncode, staging_dir
            ),
            file=sys.stderr,
        )
        return 1
    except Exception as exc:
        print(
            "ERROR: {}. Staging data was retained at {} for inspection "
            "or retry.".format(exc, staging_dir),
            file=sys.stderr,
        )
        return 1

    if args.keep_staging_on_success:
        log(
            "Transfer succeeded; retaining staging because "
            "--keep-staging-on-success was set: {}".format(staging_dir)
        )
    else:
        removed = remove_tree_best_effort(staging_dir)
        if not removed:
            log(
                "WARNING: transfer succeeded, but PanFS prevented complete "
                "local cleanup."
            )

    log(
        "Completed chunk {:05d}: transferred {} filtered parameter archives "
        "and {} untouched SDF archives.".format(
            args.chunk,
            len(archive_pairs),
            len(archive_pairs),
        )
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
