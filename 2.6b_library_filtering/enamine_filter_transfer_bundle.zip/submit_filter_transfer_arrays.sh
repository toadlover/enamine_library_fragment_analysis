#!/usr/bin/env bash
set -euo pipefail

# Submit integrated filtering + rsync transfer jobs.
# Concurrency is intentionally capped at 20 because the remote SSH/rsync
# endpoint becomes unstable above approximately 20 simultaneous transfers.

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORKER_SCRIPT="${SCRIPT_DIR}/run_filter_transfer_array_job.sh"
PYTHON_SCRIPT="${SCRIPT_DIR}/filter_and_transfer_enamine_chunk.py"

START_CHUNK=0
END_CHUNK=199
BLOCK_SIZE=10000
MAX_CONCURRENT=20
SIMILARITY_ROOT=""
STAGING_ROOT=""
LOG_DIR=""
WALLTIME="8:00"
RSYNC_PROGRESS=0

usage() {
    cat <<EOF
Usage: $0 --similarity-root PATH --staging-root PATH [options]

Required:
  --similarity-root PATH   Root containing prior similarity reports.
  --staging-root PATH      Local scratch space for temporary filtered archives.

Range:
  --start N                First chunk. Default: 0
  --end N                  Last chunk inclusive. Default: 199

LSF:
  --block-size N           Jobs per array, maximum 10000. Default: 10000
  --max-concurrent N       Concurrent complete filter+rsync jobs. Default: 20
                           Values above 20 are rejected by this controller.
  --walltime H:MM          Per-job walltime. Default: 8:00
  --log-dir PATH           Default: <staging-root>/logs

Other:
  --rsync-progress         Show rsync progress2 output in LSF logs.

Resources:
  queue=long, cores=1, memory=4 GB
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --start) START_CHUNK="$2"; shift 2 ;;
        --end) END_CHUNK="$2"; shift 2 ;;
        --block-size) BLOCK_SIZE="$2"; shift 2 ;;
        --max-concurrent) MAX_CONCURRENT="$2"; shift 2 ;;
        --walltime) WALLTIME="$2"; shift 2 ;;
        --similarity-root) SIMILARITY_ROOT="$2"; shift 2 ;;
        --staging-root) STAGING_ROOT="$2"; shift 2 ;;
        --log-dir) LOG_DIR="$2"; shift 2 ;;
        --rsync-progress) RSYNC_PROGRESS=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) echo "ERROR: unknown argument: $1" >&2; usage >&2; exit 2 ;;
    esac
done

if [[ -z "${SIMILARITY_ROOT}" || -z "${STAGING_ROOT}" ]]; then
    echo "ERROR: --similarity-root and --staging-root are required." >&2
    usage >&2
    exit 2
fi

for variable in START_CHUNK END_CHUNK BLOCK_SIZE MAX_CONCURRENT; do
    if ! [[ "${!variable}" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${variable} must be a nonnegative integer." >&2
        exit 2
    fi
done

if (( START_CHUNK > END_CHUNK || END_CHUNK > 53083 )); then
    echo "ERROR: chunk range must fall within 0-53083." >&2
    exit 2
fi

if (( BLOCK_SIZE < 1 || BLOCK_SIZE > 10000 )); then
    echo "ERROR: --block-size must be between 1 and 10000." >&2
    exit 2
fi

if (( MAX_CONCURRENT < 1 || MAX_CONCURRENT > 20 )); then
    echo "ERROR: --max-concurrent must be between 1 and 20." >&2
    exit 2
fi

if [[ ! -f "${WORKER_SCRIPT}" || ! -f "${PYTHON_SCRIPT}" ]]; then
    echo "ERROR: required script is missing from ${SCRIPT_DIR}." >&2
    exit 2
fi

mkdir -p "${STAGING_ROOT}"
SIMILARITY_ROOT="$(cd "${SIMILARITY_ROOT}" && pwd)"
STAGING_ROOT="$(cd "${STAGING_ROOT}" && pwd)"

if [[ -z "${LOG_DIR}" ]]; then
    LOG_DIR="${STAGING_ROOT}/logs"
fi
mkdir -p "${LOG_DIR}"
LOG_DIR="$(cd "${LOG_DIR}" && pwd)"

BLOCK_START="${START_CHUNK}"
SUBMISSION_COUNT=0

while (( BLOCK_START <= END_CHUNK )); do
    BLOCK_END=$((BLOCK_START + BLOCK_SIZE - 1))
    if (( BLOCK_END > END_CHUNK )); then
        BLOCK_END="${END_CHUNK}"
    fi

    ELEMENT_COUNT=$((BLOCK_END - BLOCK_START + 1))
    JOB_NAME="filter_xfer_${BLOCK_START}_${BLOCK_END}[1-${ELEMENT_COUNT}]%${MAX_CONCURRENT}"

    echo "Submitting chunks ${BLOCK_START}-${BLOCK_END} with concurrency ${MAX_CONCURRENT}"

    bsub \
        -J "${JOB_NAME}" \
        -q long \
        -W "${WALLTIME}" \
        -n 1 \
        -M 4000 \
        -R "rusage[mem=4000] span[hosts=1]" \
        -oo "${LOG_DIR}/filter_xfer_%J_%I.out" \
        -eo "${LOG_DIR}/filter_xfer_%J_%I.err" \
        /bin/bash "${WORKER_SCRIPT}" \
            "${BLOCK_START}" \
            "${SIMILARITY_ROOT}" \
            "${STAGING_ROOT}" \
            "${PYTHON_SCRIPT}" \
            "${RSYNC_PROGRESS}"

    SUBMISSION_COUNT=$((SUBMISSION_COUNT + 1))
    BLOCK_START=$((BLOCK_END + 1))
done

echo "Submitted ${SUBMISSION_COUNT} array block(s)."
