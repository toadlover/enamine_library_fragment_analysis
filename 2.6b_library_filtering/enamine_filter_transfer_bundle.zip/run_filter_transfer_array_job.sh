#!/usr/bin/env bash
set -euo pipefail

# One LSF array element runs one complete filter + transfer operation.

if [[ $# -ne 5 ]]; then
    echo "Usage: $0 BLOCK_START SIMILARITY_ROOT STAGING_ROOT PYTHON_SCRIPT RSYNC_PROGRESS" >&2
    exit 2
fi

BLOCK_START="$1"
SIMILARITY_ROOT="$2"
STAGING_ROOT="$3"
PYTHON_SCRIPT="$4"
RSYNC_PROGRESS="$5"

if [[ -z "${LSB_JOBINDEX:-}" ]]; then
    echo "ERROR: LSB_JOBINDEX is not set." >&2
    exit 2
fi

CHUNK=$((BLOCK_START + LSB_JOBINDEX - 1))
CHUNK_PADDED=$(printf "%05d" "${CHUNK}")

ARGS=(
    "${CHUNK_PADDED}"
    "${SIMILARITY_ROOT}"
    "${STAGING_ROOT}"
)

if [[ "${RSYNC_PROGRESS}" == "1" ]]; then
    ARGS+=(--rsync-progress)
fi

python "${PYTHON_SCRIPT}" "${ARGS[@]}"
