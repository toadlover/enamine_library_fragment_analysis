#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SIM=""; OUT=""; ARRAY="0-530%1"; WORKERS=60; CPUS=60; MEM=120G; TIME=24:00:00; SCRATCH=/scratch/ari_ginsparg_umassmed
while [[ $# -gt 0 ]]; do case "$1" in
 --similarity-root) SIM="$2"; shift 2;; --output-root) OUT="$2"; shift 2;; --array) ARRAY="$2"; shift 2;;
 --workers) WORKERS="$2"; shift 2;; --cpus) CPUS="$2"; shift 2;; --mem) MEM="$2"; shift 2;; --time) TIME="$2"; shift 2;;
 --scratch-root) SCRATCH="$2"; shift 2;; *) echo "unknown option $1" >&2; exit 2;; esac; done
[[ -n "$SIM" && -n "$OUT" ]] || { echo 'need --similarity-root and --output-root' >&2; exit 2; }
mkdir -p "$SCRATCH/enamine_filter_logs" "$OUT"
sbatch --partition=cpu --array="$ARRAY" --cpus-per-task="$CPUS" --mem="$MEM" --time="$TIME" \
 --export="ALL,SIMILARITY_ROOT=$SIM,OUTPUT_ROOT=$OUT,SCRATCH_ROOT=$SCRATCH,WORKERS=$WORKERS" \
 "$SCRIPT_DIR/run_enamine_superchunk_array.sbatch"
