#!/usr/bin/env python3
import argparse, csv, io, json, os, re, shutil, subprocess, sys, tarfile, tempfile, time
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

LIBRARY_ROOT_DEFAULT = Path("/work/umassmed/thymelab_umassmed/2.6b_conformer_library")
SCRATCH_ROOT_DEFAULT = Path("/scratch/ari_ginsparg_umassmed")
SUBCHUNKS = range(10)

def log(msg): print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)

def run(cmd):
    return subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def rm_tree(path):
    if path.exists(): shutil.rmtree(path, ignore_errors=True)
    return not path.exists()

def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("superchunk", type=int)
    p.add_argument("similarity_root", type=Path)
    p.add_argument("output_root", type=Path)
    p.add_argument("--library-root", type=Path, default=LIBRARY_ROOT_DEFAULT)
    p.add_argument("--scratch-root", type=Path, default=SCRATCH_ROOT_DEFAULT)
    p.add_argument("--workers", type=int, default=60)
    p.add_argument("--overwrite", action="store_true")
    p.add_argument("--keep-manifests", action="store_true")
    p.add_argument("--delete-source-on-success", action="store_true")
    return p.parse_args()

def locate_report(root, chunk):
    d=root/str(chunk//100)/f"{chunk:05d}"
    for p in (d/f"chunk_{chunk:05d}_similarity_report.csv.tar.gz", d/f"chunk_{chunk:05d}_similarity_report.csv"):
        if p.is_file(): return p
    raise FileNotFoundError(f"similarity report missing for {chunk:05d}")

def parse_subchunk(name):
    m=re.search(r"split_new_named_(\d+)\.sdf(?:\.tar\.gz)?$", name.strip())
    if not m: raise ValueError(f"cannot parse subchunk from {name}")
    return int(m.group(1))

def read_similarity(path):
    grouped={i:set() for i in SUBCHUNKS}
    def consume(h):
        r=csv.DictReader(h)
        for row in r:
            if (row.get("status") or "").strip().lower()=="removed":
                grouped[int(row["subchunk"])].add(row["name"].strip())
    if path.name.endswith(".tar.gz"):
        with tarfile.open(path,"r:gz") as tf:
            ms=[m for m in tf.getmembers() if m.isfile() and m.name.endswith(".csv")]
            if len(ms)!=1: raise ValueError(f"expected one csv in {path}")
            raw=tf.extractfile(ms[0])
            with io.TextIOWrapper(raw,encoding="utf-8-sig",newline="") as h: consume(h)
    else:
        with path.open(encoding="utf-8-sig",newline="") as h: consume(h)
    return grouped

def read_blacklist(path):
    grouped={i:set() for i in SUBCHUNKS}
    with path.open(encoding="utf-8-sig",newline="") as h:
        for row in csv.DictReader(h):
            if row.get("ligand"):
                grouped[parse_subchunk(row["subchunk_splitfile"])].add(row["ligand"].strip())
    return grouped

def esc(s):
    return s.replace("[","[[]").replace("*","[*]").replace("?","[?]")

def write_manifest(path,names):
    with path.open("w") as h:
        h.write("db.db\n*lig_name_lis*\n")
        for n in sorted(names): h.write(f"*{esc(n)}*\n")

def members(path): return [x for x in run(["tar","-tzf",str(path)]).stdout.splitlines() if x]

def root_member(ms):
    roots=set()
    pat=re.compile(r"^((?:\./)?condensed_params_and_db_[^/]+/single_conf_params)(?:/|$)")
    for m in ms:
        q=pat.match(m)
        if q: roots.add(q.group(1))
    if len(roots)!=1: raise RuntimeError(f"expected one single_conf_params root, found {len(roots)}")
    return next(iter(roots))

def validate_tar(path):
    for m in members(path):
        if ("single_conf_params" not in m) or m.endswith("/db.db") or "lig_name_lis" in m:
            raise RuntimeError(f"invalid member {m} in {path}")

def build_param(src,dst,manifest,work,sub):
    ex=work/f"extract_{sub}"; ex.mkdir(parents=True,exist_ok=True)
    partial=dst.with_name(dst.name+".partial")
    try:
        root=root_member(members(src))
        run(["tar","-xzf",str(src),"-C",str(ex),"--wildcards","--no-anchored","--exclude-from",str(manifest),root])
        run(["tar","-czf",str(partial),"-C",str(ex),root])
        validate_tar(partial)
        os.replace(partial,dst)
    finally:
        if partial.exists(): partial.unlink()
        rm_tree(ex)

def copy_atomic(src,dst,overwrite):
    dst.parent.mkdir(parents=True,exist_ok=True)
    if dst.exists():
        if not overwrite: raise FileExistsError(dst)
        dst.unlink()
    partial=dst.with_name(dst.name+".partial")
    if partial.exists(): partial.unlink()
    shutil.copy2(src,partial)
    if partial.stat().st_size!=src.stat().st_size: raise RuntimeError(f"size mismatch copying {src}")
    os.replace(partial,dst)

def process_chunk(cfg,chunk):
    lib=Path(cfg["library"]); simroot=Path(cfg["similarity"]); outroot=Path(cfg["output"]); scratchroot=Path(cfg["scratch"])
    overwrite=cfg["overwrite"]; keep=cfg["keep"]; delete_source=cfg["delete"]
    sc=chunk//100; c=f"{chunk:05d}"
    srcdir=lib/str(sc)/c; final=outroot/str(sc)/c; marker=final/f"chunk_{c}.complete"
    if marker.exists() and not overwrite: return ("skipped",0.0)
    if not srcdir.is_dir(): raise FileNotFoundError(srcdir)
    start=time.time()
    scratch=Path(tempfile.mkdtemp(prefix=f"chunk_{c}_",dir=str(scratchroot/"enamine_filter"/str(sc))))
    gen=scratch/"generated"; work=scratch/"work"; mans=scratch/"manifests"
    for d in (gen,work,mans): d.mkdir(parents=True,exist_ok=True)
    try:
        sim=read_similarity(locate_report(simroot,chunk))
        black=read_blacklist(srcdir/"blacklist_file.csv")
        params=[]; sdfs=[]
        for i in SUBCHUNKS:
            ps=srcdir/f"condensed_params_and_db_{i}.tar.gz"
            ss=srcdir/f"split_new_named_{i}.sdf.tar.gz"
            if not ps.is_file() or not ss.is_file(): raise FileNotFoundError(f"missing archive pair for {c} subchunk {i}")
            man=mans/f"exclude_{i}.txt"; write_manifest(man,black[i]|sim[i])
            pd=gen/ps.name; build_param(ps,pd,man,work,i)
            params.append(pd); sdfs.append(ss)
            if keep: shutil.copy2(man,gen/f"chunk_{c}_exclude_{i}.txt")
        final.mkdir(parents=True,exist_ok=True)
        for p in params+sdfs: copy_atomic(p,final/p.name,overwrite)
        for p in params+sdfs:
            if (final/p.name).stat().st_size!=p.stat().st_size: raise RuntimeError(f"final size mismatch {p.name}")
        summary=final/f"chunk_{c}_summary.json.partial"
        summary.write_text(json.dumps({"chunk":chunk,"filtered_params":[p.name for p in params],"copied_sdfs":[p.name for p in sdfs],"delete_source_on_success":delete_source},indent=2)+"\n")
        os.replace(summary,final/f"chunk_{c}_summary.json")
        mp=final/f"chunk_{c}.complete.partial"; mp.write_text(f"chunk={c}\narchives=20\ncompleted={time.strftime('%Y-%m-%d %H:%M:%S')}\n")
        os.replace(mp,marker)
        if delete_source:
            if srcdir.resolve()==final.resolve(): raise RuntimeError("source and output directories are identical")
            if not rm_tree(srcdir): raise RuntimeError(f"could not fully delete source {srcdir}")
        rm_tree(scratch)
        return ("completed",time.time()-start)
    except Exception as e:
        raise RuntimeError(f"chunk {c} failed: {e}; scratch retained at {scratch}")

def main():
    a=parse_args()
    lib=a.library_root.resolve(); sim=a.similarity_root.resolve(); out=a.output_root.resolve(); scratch=a.scratch_root.resolve()
    (scratch/"enamine_filter"/str(a.superchunk)).mkdir(parents=True,exist_ok=True); out.mkdir(parents=True,exist_ok=True)
    scdir=lib/str(a.superchunk)
    chunks=sorted(int(p.name) for p in scdir.iterdir() if p.is_dir() and re.fullmatch(r"\d{5}",p.name))
    cpus=int(os.environ.get("SLURM_CPUS_PER_TASK",a.workers)); workers=min(a.workers,cpus,len(chunks))
    cfg={"library":str(lib),"similarity":str(sim),"output":str(out),"scratch":str(scratch),"overwrite":a.overwrite,"keep":a.keep_manifests,"delete":a.delete_source_on_success}
    failures=[]
    with ProcessPoolExecutor(max_workers=workers) as ex:
        futs={ex.submit(process_chunk,cfg,c):c for c in chunks}
        for f in as_completed(futs):
            c=futs[f]
            try:
                status,elapsed=f.result(); log(f"chunk {c:05d}: {status} ({elapsed:.1f}s)")
            except Exception as e:
                failures.append((c,str(e))); log(f"ERROR chunk {c:05d}: {e}")
    if failures: return 1
    (out/str(a.superchunk)/f"superchunk_{a.superchunk}.complete").write_text(f"superchunk={a.superchunk}\ncompleted={time.strftime('%Y-%m-%d %H:%M:%S')}\n")
    return 0

if __name__=="__main__": sys.exit(main())
