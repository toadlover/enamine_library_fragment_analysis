#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
SBATCH_SCRIPT="${SCRIPT_DIR}/run_enamine_superchunk_array.sbatch"
PYTHON_SCRIPT="${SCRIPT_DIR}/filter_enamine_superchunk_slurm.py"
LIBRARY_ROOT="/work/umassmed/thymelab_umassmed/2.6b_conformer_library"
SCRATCH_ROOT="/scratch/ari_ginsparg_umassmed"
ARRAY_RANGE="0-530%1"; WORKERS=60; CPUS=60; MEMORY=120G; WALLTIME=24:00:00
SIMILARITY_ROOT=""; OUTPUT_ROOT=""; OVERWRITE=0; KEEP_MANIFESTS=0; DELETE_SOURCE_ON_SUCCESS=0
while [[ $# -gt 0 ]]; do
 case "$1" in
  --library-root) LIBRARY_ROOT="$2"; shift 2;;
  --similarity-root) SIMILARITY_ROOT="$2"; shift 2;;
  --output-root) OUTPUT_ROOT="$2"; shift 2;;
  --scratch-root) SCRATCH_ROOT="$2"; shift 2;;
  --array) ARRAY_RANGE="$2"; shift 2;;
  --workers) WORKERS="$2"; shift 2;;
  --cpus) CPUS="$2"; shift 2;;
  --mem) MEMORY="$2"; shift 2;;
  --time) WALLTIME="$2"; shift 2;;
  --overwrite) OVERWRITE=1; shift;;
  --keep-manifests) KEEP_MANIFESTS=1; shift;;
  --delete-source-on-success) DELETE_SOURCE_ON_SUCCESS=1; shift;;
  *) echo "unknown argument $1" >&2; exit 2;;
 esac
done
[[ -n "$SIMILARITY_ROOT" && -n "$OUTPUT_ROOT" ]] || { echo "similarity/output roots required" >&2; exit 2; }
mkdir -p "$OUTPUT_ROOT" "$SCRATCH_ROOT" /scratch/ari_ginsparg_umassmed/enamine_filter_logs
for p in "$SBATCH_SCRIPT" "$PYTHON_SCRIPT"; do [[ -f "$p" ]] || { echo "missing $p" >&2; exit 2; }; done
for p in "$LIBRARY_ROOT" "$SIMILARITY_ROOT"; do [[ -d "$p" ]] || { echo "missing dir $p" >&2; exit 2; }; done
SBATCH_SCRIPT="$(readlink -f "$SBATCH_SCRIPT")"; PYTHON_SCRIPT="$(readlink -f "$PYTHON_SCRIPT")"
LIBRARY_ROOT="$(readlink -f "$LIBRARY_ROOT")"; SIMILARITY_ROOT="$(readlink -f "$SIMILARITY_ROOT")"
OUTPUT_ROOT="$(readlink -f "$OUTPUT_ROOT")"; SCRATCH_ROOT="$(readlink -f "$SCRATCH_ROOT")"
[[ "$LIBRARY_ROOT" != "$OUTPUT_ROOT" ]] || { echo "source and output roots must differ" >&2; exit 2; }
EXPORTS="ALL,LIBRARY_ROOT=${LIBRARY_ROOT},SIMILARITY_ROOT=${SIMILARITY_ROOT},OUTPUT_ROOT=${OUTPUT_ROOT},SCRATCH_ROOT=${SCRATCH_ROOT},WORKERS=${WORKERS},OVERWRITE=${OVERWRITE},KEEP_MANIFESTS=${KEEP_MANIFESTS},DELETE_SOURCE_ON_SUCCESS=${DELETE_SOURCE_ON_SUCCESS}"
sbatch --partition=cpu --array="$ARRAY_RANGE" --cpus-per-task="$CPUS" --mem="$MEMORY" --time="$WALLTIME" --export="$EXPORTS" "$SBATCH_SCRIPT" "$PYTHON_SCRIPT"
